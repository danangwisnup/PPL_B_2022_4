

<?php $__env->startSection('content'); ?>

<div class="container-scroller">

    <?php echo $__env->make('layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main>
        <!-- Container START -->
        <div class="container">
            <div class="row g-4">
                <?php if(Auth::user()->role == 'operator'): ?>
                <?php echo $__env->make('operator.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php elseif(Auth::user()->role == 'mahasiswa'): ?>
                <?php echo $__env->make('operator.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php elseif(Auth::user()->role == 'dosen'): ?>
                <?php echo $__env->make('dosen.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php else: ?>
                <?php echo $__env->make('depaertemen.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php endif; ?>
            </div> <!-- Row END -->
        </div>
        <!-- Container END -->
    </main>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ppl-project\resources\views/dashboard/index.blade.php ENDPATH**/ ?>