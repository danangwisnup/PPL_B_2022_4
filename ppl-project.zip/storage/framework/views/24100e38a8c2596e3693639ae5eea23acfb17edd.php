<!DOCTYPE html>
<html lang="en">

<head>
    <title>SIMI | <?php echo e($title); ?> </title>

    <!-- Meta Tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="author" content="Webestica.com">
    <meta name="description" content="Bootstrap 5 based Social Media Network and Community Theme">

    <!-- Favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('assets/images/undip.png')); ?>">

    <!-- Google Font -->
    <link rel="preconnect" href="https://fonts.googleapis.com/">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&amp;display=swap">

    <!-- Plugins CSS -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/vendor/font-awesome/css/all.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/vendor/bootstrap-icons/bootstrap-icons.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/vendor/OverlayScrollbars-master/css/OverlayScrollbars.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/vendor/tiny-slider/dist/tiny-slider.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/vendor/choices.js/public/assets/styles/choices.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/vendor/glightbox-master/dist/css/glightbox.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/vendor/dropzone/dist/dropzone.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/vendor/flatpickr/dist/flatpickr.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/vendor/plyr/plyr.css')); ?>">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.12.1/css/jquery.dataTables.min.css">

    <!-- Theme CSS -->
    <link id="style-switch" rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/style.css')); ?>">

</head>

<body>

    <?php echo $__env->yieldContent('content'); ?>;

    <!-- Bootstrap JS -->
    <script src="<?php echo e(asset('assets/vendor/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>"></script>

    <!-- Vendors -->
    <script src="<?php echo e(asset('assets/vendor/tiny-slider/dist/tiny-slider.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/OverlayScrollbars-master/js/OverlayScrollbars.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/choices.js/public/assets/scripts/choices.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/glightbox-master/dist/js/glightbox.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/flatpickr/dist/flatpickr.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/plyr/plyr.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendor/dropzone/dist/min/dropzone.min.js')); ?>"></script>

    <!-- Template Functions -->
    <script src="<?php echo e(asset('assets/js/template.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/javascript-ajax.js')); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
    <script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>

    <!-- React JS -->
    <!-- <script crossorigin src="https://unpkg.com/react@18/umd/react.production.min.js"></script>
    <script crossorigin src="https://unpkg.com/react-dom@18/umd/react-dom.production.min.js"></script> -->

</body>

</html><?php /**PATH C:\laragon\www\ppl-project\resources\views/layouts/main.blade.php ENDPATH**/ ?>