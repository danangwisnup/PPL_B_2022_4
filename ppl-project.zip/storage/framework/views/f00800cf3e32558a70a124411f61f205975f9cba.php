

<?php $__env->startSection('content'); ?>

<div class="container-scroller" id="bar">

    <?php echo $__env->make('components.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

    <!-- **************** MAIN CONTENT START **************** -->
    <main>

        <!-- Container START -->
        <div class="container">
            <div class="row g-4">

                <!-- Sidenav START -->
                <div class="col-lg-3">

                    <!-- Advanced filter responsive toggler START -->
                    <div class="d-flex align-items-center d-lg-none">
                        <button class="border-0 bg-transparent" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasSideNavbar" aria-controls="offcanvasSideNavbar">
                            <i class="btn btn-primary fw-bold fa-solid fa-sliders-h"></i>
                            <span class="h6 mb-0 fw-bold d-lg-none ms-2">My profile</span>
                        </button>
                    </div>
                    <!-- Advanced filter responsive toggler END -->

                    <!-- Navbar START-->
                    <nav class="navbar navbar-expand-lg mx-0">
                        <div class="offcanvas offcanvas-start" tabindex="-1" id="offcanvasSideNavbar">
                            <!-- Offcanvas header -->
                            <div class="offcanvas-header">
                                <button type="button" class="btn-close text-reset ms-auto" data-bs-dismiss="offcanvas" aria-label="Close"></button>
                            </div>

                            <!-- Offcanvas body -->
                            <div class="offcanvas-body d-block px-2 px-lg-0">
                                <!-- Card START -->
                                <div class="card overflow-hidden">
                                    <!-- Cover image -->
                                    <div class="h-50px" style="background-image:url(assets/images/bg/01.jpg); background-position: center; background-size: cover; background-repeat: no-repeat;"></div>
                                    <!-- Card body START -->
                                    <div class="card-body pt-0">
                                        <div class="text-center">
                                            <!-- Avatar -->
                                            <div class="avatar avatar-lg mt-n5 mb-3">
                                                <a href="#!"><img class="avatar-img rounded border border-white border-3" src="assets/images/avatar/07.jpg" alt=""></a>
                                            </div>
                                            <!-- Info -->
                                            <h5 class="mb-0"> <a href="#!">Danang Wisnu Prayoga</a> </h5>
                                            <small class="mb-2">danangwisnu9502@gmail.com</small>
                                            <br>
                                            <small>admin</small>
                                            <hr>
                                            <h6 class="mb-0">Balance</h6>
                                            <p id="getBalance">Rp 97.690.102,00</p>

                                        </div>

                                        <!-- Divider -->
                                        <hr>

                                        <!-- Side Nav START -->
                                        <ul class="nav nav-tabs nav-pills nav-pills-soft flex-column fw-bold gap-0 border-0">
                                            <li>
                                                <a class="dropdown-item active" href="/"><i class="bi bi-house-door"></i><span> Dashboard</span></a>
                                            </li>
                                            <li>
                                                <a class="dropdown-item" href="javascript:;" onclick="load('pages/transaksi/pembelian-pulsa');"><i class="bi bi-cart"></i><span> Pembelian Pulsa</span></a>
                                            </li>
                                            <li>
                                                <a class="dropdown-item" href="javascript:;" onclick="load('pages/transaksi/topup-balance');"><i class="bi bi-currency-exchange"></i><span> Topup Balance</span></a>
                                            </li>
                                            <li>
                                                <a class="dropdown-item" href="javascript:;" onclick="load('pages/transaksi/history-pembelian');"><i class="bi bi-cart-check-fill"></i><span> History Pembelian Pulsa</span></a>
                                            </li>
                                            <li>
                                                <a class="dropdown-item" href="javascript:;" onclick="load('pages/transaksi/history-topup');"><i class="bi bi-cash-stack"></i><span> History Topup Balance</span></a>
                                            </li>
                                        </ul>
                                        <!-- Side Nav END -->
                                    </div>
                                    <!-- Card body END -->
                                    <!-- Card footer -->
                                    <div class="card-footer text-center py-2">
                                        <a class="btn btn-link btn-sm" href="javascript:;">View Profile </a>
                                    </div>
                                </div>
                                <!-- Card END -->
                            </div>
                        </div>
                    </nav>
                    <!-- Navbar END-->
                </div>
                <!-- Sidenav END -->
                <div class="col-md-9">
                    <div id="partialPage">
                        <div class="row">

                            <div class="col-md-8">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="card-title">Anggota Kelompok</h5>
                                        <div class="nav-link d-flex">
                                            <i class="fa-solid fa-angle-right text-primary pt-1 fa-fw me-2"></i>Danang Wisnu Prayoga - 24060120140160
                                        </div>
                                        <div class="nav-link d-flex">
                                            <i class="fa-solid fa-angle-right text-primary pt-1 fa-fw me-2"></i>Agung Ramadhani - 24060120120016
                                        </div>
                                        <div class="nav-link d-flex">
                                            <i class="fa-solid fa-angle-right text-primary pt-1 fa-fw me-2"></i>Annas Bachtiar - 24060120140151
                                        </div>
                                        <div class="nav-link d-flex">
                                            <i class="fa-solid fa-angle-right text-primary pt-1 fa-fw me-2"></i>Farrel Samuel Nicholas - 24060120130121
                                        </div>
                                        <div class="nav-link d-flex">
                                            <i class="fa-solid fa-angle-right text-primary pt-1 fa-fw me-2"></i>Rijal Kurniawan - 24060120120001
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="card-title">Informasi Transaksi</h5>
                                        <br />
                                        <!-- User stat START -->
                                        <div class="hstack gap-2 gap-xl-3 justify-content-center text-center">
                                            <!-- User stat item -->
                                            <div>
                                                <h6 class="mb-0">4</h6>
                                                <small>Transaksi Pulsa</small>
                                            </div>
                                            <!-- Divider -->
                                            <div class="vr"></div>
                                            <!-- User stat item -->
                                            <div>
                                                <h6 class="mb-0">3</h6>
                                                <small>Topup Balance</small>
                                            </div>
                                        </div>
                                        <!-- User stat END -->
                                        <hr>
                                        <strong class="mb-0"> Total Pembelian Pulsa </strong>
                                        <h6 class="mb-0">Rp 19.800,00</h6>
                                        <br />
                                        <strong class="mb-0"> Total Topup Balance </strong>
                                        <h6 class="mb-0">Rp 87.712.408,00</h6>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <!-- Right sidebar END -->

            </div> <!-- Row END -->
        </div>
        <!-- Container END -->

    </main>
    <!-- **************** MAIN CONTENT END **************** -->

    <!-- modal user -->
    <div class="modal fade" data-bs-backdrop="static" data-keyboard="false" id="user_modal_view" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Edit User</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form>
                        <div class="form-group row">
                            <div class="col">
                                <label for="recipient-name" class="col-form-label">Nama </label>
                                <input type="text" class="form-control" id="user_nama" name="user_nama">
                            </div>
                            <div class="col">
                                <label for="recipient-name" class="col-form-label">Level </label>
                                <select class="form-control" id="user_level" name="user_level">
                                    <option value="">-- Pilih Level --</option>
                                    <option value="admin">Admin</option>
                                    <option value="member">Member</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="recipient-name" class="col-form-label">Email </label>
                            <input type="text" class="form-control" id="user_email" name="user_email" readonly>
                        </div>
                        <div class="form-group row">
                            <div class="col">
                                <label for="recipient-name" class="col-form-label">Balance </label>
                                <input type="number" class="form-control" id="user_balance" name="user_balance">
                            </div>
                            <div class="col">
                                <label for="recipient-name" class="col-form-label">Status </label>
                                <select class="form-control" id="user_status" name="user_status">
                                    <option value="">-- Pilih Status --</option>
                                    <option value="aktif">Aktif</option>
                                    <option value="nonaktif">Nonaktif</option>
                                </select>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary" data-bs-dismiss="modal" onclick="user_update()">Submit</button>
                    <button type="button" class="btn btn-dark" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div> <!-- modal pembelian -->
    <div class="modal fade" data-bs-backdrop="static" data-keyboard="false" id="pembelian_modal_view" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Data Pembelian</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form>
                        <div class="form-group row">
                            <div class="col-2">
                                <label for="recipient-name" class="col-form-label">#Order </label>
                                <input type="text" class="form-control" id="pembelian_id" name="pembelian_id" readonly>
                            </div>
                            <div class="col-10">
                                <label for="recipient-name" class="col-form-label">Email </label>
                                <input type="text" class="form-control" id="pembelian_email" name="pembelian_email" readonly>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="recipient-name" class="col-form-label">Deskripsi </label>
                            <h6 id="pembelian_deskripsi" name="pembelian_deskripsi"></h6>
                        </div>
                        <div class="form-group row">
                            <div class="col">
                                <label for="recipient-name" class="col-form-label">Harga </label>
                                <input type="number" class="form-control" id="pembelian_harga" name="pembelian_harga" readonly>
                            </div>
                            <div class="col">
                                <label for="recipient-name" class="col-form-label">Status </label>
                                <select class="form-control" id="pembelian_status" name="pembelian_status">
                                    <option value="">-- Pilih Status --</option>
                                    <option value="pending">Pending</option>
                                    <option value="success">Success</option>
                                    <option value="failed">Failed</option>
                                </select>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary" data-bs-dismiss="modal" onclick="pembelian_update()">Submit</button>
                    <button type="button" class="btn btn-dark" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div> <!-- modal topup -->
    <div class="modal fade" data-bs-backdrop="static" data-keyboard="false" id="topup_modal_view" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Edit Data Topup</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form>
                        <div class="form-group row">
                            <div class="col-2">
                                <label for="recipient-name" class="col-form-label">#Order </label>
                                <input type="number" class="form-control" id="topup_id" name="topup_id" readonly>
                            </div>
                            <div class="col-10">
                                <label for="recipient-name" class="col-form-label">Email </label>
                                <input type="text" class="form-control" id="topup_email" name="topup_email" readonly>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="recipient-name" class="col-form-label">Deskripsi </label>
                            <h6 id="topup_deskripsi" name="topup_deskripsi"></h6>
                        </div>
                        <div class="form-group row">
                            <div class="col">
                                <label for="recipient-name" class="col-form-label">Nominal </label>
                                <input type="number" class="form-control" id="topup_nominal" name="topup_nominal" readonly>
                            </div>
                            <div class="col">
                                <label for="recipient-name" class="col-form-label">Status </label>
                                <select class="form-control" id="topup_status" name="topup_status">
                                    <option value="">-- Pilih Status --</option>
                                    <option value="pending">Pending</option>
                                    <option value="success">Success</option>
                                    <option value="failed">Failed</option>
                                </select>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary" data-bs-dismiss="modal" onclick="topup_update()">Submit</button>
                    <button type="button" class="btn btn-dark" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ppl-project\resources\views/dashboard/admin.blade.php ENDPATH**/ ?>