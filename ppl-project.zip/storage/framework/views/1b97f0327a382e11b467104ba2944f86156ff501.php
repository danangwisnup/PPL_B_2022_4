    <!-- Header START -->
    <header class="navbar-light fixed-top header-static bg-mode">

        <!-- Logo Nav START -->
        <nav class="navbar navbar-expand-lg">
            <div class="container">
                <!-- Logo START -->
                <a class="navbar-brand" href="/">
                    <img class="light-mode-item navbar-brand-item" src="assets/images/logo.svg" alt="logo">
                </a>
                <!-- Logo END -->

                <!-- Responsive navbar toggler -->
                <button class="navbar-toggler ms-auto icon-md btn btn-light p-0" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-animation">
                        <span></span>
                        <span></span>
                        <span></span>
                    </span>
                </button>

                <!-- Main navbar START -->
                <div class="collapse navbar-collapse" id="navbarCollapse">

                    <ul class="navbar-nav navbar-nav-scroll ms-auto">
                        <!-- Nav admin -->
                        <li class="nav-item dropdown">
                            <a class="dropdown-item" href="#" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Admin Panel</a>
                            <ul class="dropdown-menu" aria-labelledby="homeMenu">
                                <!-- Nav admin -->
                                <li class="dropdown-divider"></li>
                                <li> <a class="dropdown-item" href="javascript:;" onclick="load('pages/admin/user');">Manajemen User</a></li>
                                <li> <a class="dropdown-item" href="javascript:;" onclick="load('pages/admin/pembelian');">Manajemen Pembelian</a></li>
                                <li> <a class="dropdown-item" href="javascript:;" onclick="load('pages/admin/topup');">Manajemen Topup</a></li>
                                <li> <a class="dropdown-item" href="javascript:;" onclick="load('pages/admin/provider_nominal');">Manajemen Provider</a></li>
                                <li> <a class="dropdown-item" href="javascript:;" onclick="load('pages/admin/metode_topup');">Manajemen Metode Topup</a></li>
                                <li class="dropdown-divider"></li>
                            </ul>
                        </li>
                    </ul>
                </div>
                <!-- Main navbar END -->

                <!-- Nav right START -->
                <ul class="nav flex-nowrap align-items-center ms-sm-3 list-unstyled">

                    <li class="nav-item ms-2 dropdown">
                        <a class="nav-link btn icon-md p-0" href="#" id="profileDropdown" role="button" data-bs-auto-close="outside" data-bs-display="static" data-bs-toggle="dropdown" aria-expanded="false">
                            <img class="avatar-img rounded-2" src="assets/images/avatar/07.jpg" alt="">
                        </a>
                        <ul class="dropdown-menu dropdown-animation dropdown-menu-end pt-3 small me-md-n3" aria-labelledby="profileDropdown">
                            <!-- Profile info -->
                            <li class="px-3">
                                <div class="d-flex align-items-center position-relative">
                                    <!-- Avatar -->
                                    <div class="avatar me-3">
                                        <img class="avatar-img rounded-circle" src="assets/images/avatar/07.jpg" alt="avatar">
                                    </div>
                                    <div>
                                        <a class="h6 stretched-link" href="#">Danang Wisnu Prayoga</a>
                                        <p class="small m-0">admin</p>
                                    </div>
                                </div>
                                <a class="dropdown-item btn btn-primary-soft btn-sm my-2 text-center" href="javascript:;">View profile</a>
                            </li>
                            <li class="dropdown-divider"></li>
                            <li><a class="dropdown-item bg-danger-soft-hover" href="/logout"><i class="bi bi-power fa-fw me-2"></i>Sign Out</a></li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                        </ul>
                    </li>
                    <!-- Profile START -->

                </ul>
                <!-- Nav right END -->
            </div>
        </nav>
        <!-- Logo Nav END -->
    </header><?php /**PATH C:\laragon\www\ppl-project\resources\views/component/navbar.blade.php ENDPATH**/ ?>